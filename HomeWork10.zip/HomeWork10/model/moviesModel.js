const Pool = require('../config/connection')

class Movies {
    constructor(id, title, genres, year, photo){
        this.id = id;
        this.title = title;
        this.genres = genres;
        this.year = year;
        this.photo = photo;
    }
    static showMovies(callback){
        const query = 'SELECT * FROM public.movies'
        Pool.query(query, (error, result)=>{
            if(error){
                callback(error, null)
            }else{
                callback(null, result.rows)
            }
        })
    }

    static showMovies(callback){
        const query = 'SELECT * FROM public.movies'
        Pool.query(query, (error, result)=>{
            if(error){
                callback(error, null)
            }else{
                callback(null, result.rows)
            }
        })
    }
}
module.exports = Movies