const express = require('express')
const app = express()
const port = 8080
const multer = require('multer')
const movies = require('./routes/movies')
const bodyParser = require('body-parser')

app.use(bodyParser.json())

// dependency path
const path = require('path');

const diskStorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, path.join(__dirname, "/uploads"));
    },
    // konfigurasi penamaan file yang unik
    filename: function (req, file, cb) {
      cb(
        null,
        file.fieldname + "-" + Date.now() + path.extname(file.originalname)
      );
    },
  });

app.use(movies)

app.put(
    "/contact/upload",
    multer({ storage: diskStorage }).single("photo"),
    (req, res) => {
      const file = req.file.path;
      if (!file) {
        res.status(400).send({
          status: false,
          data: "No File is selected.",
        });
      }
      res.send(file);
    }
  );

app.listen(port, ()=>{
    console.log(`App is running on http://localhost:${port}`)
})