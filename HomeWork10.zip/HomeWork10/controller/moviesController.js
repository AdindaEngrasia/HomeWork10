const Movies = require('../model/moviesModel')

class Controller {
    static showMovies(req, res){
        Movies.showMovies((error, result)=>{
            if(error){
                console.log(error)
                result.status(500).json({ error: 'Internal server error'});
            }else{
                res.json(result)
            }
        })
    }
}
module.exports = Controller