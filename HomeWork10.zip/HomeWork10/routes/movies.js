const express = require('express')
const route = express.Router()
const Controller = require('../controller/moviesController')

route.get('/', Controller.showMovies) 

module.exports = route